###12.Write a program find all even number from the given input list and display output as a list format. 
x=[12,15,13,11,10]
"""
num = int(input("Enter a number:"))
if (num % 2) == 0:
   print("{0} is Even".format(num))
else:
   print("{0} is Odd".format(num))
"""
z=[]
x=[]
for i in x:
   if(i%2)==0:
      print(" is even.format []")
      z.append(i)
   else:
      print(" is not even []")
      x.append[i]

