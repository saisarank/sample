#Write a program create 3x3 matrix using python. Take all the elements from the
#user. And also print the sum of diagonal elements from created matrix

y=[]
for i in range(0,3):
    z=[]
    for j in range(0,3):
        ele=input("enter element:")
        z.append(ele)
    y.append(z)
print(y)
