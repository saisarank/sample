#5.Write a program replace each string with an integer value in a given list of strings. The replacement integer value should be sum of ascci values of each character of the same string. 
#holy_rivers =["Ganges", "Godavari", "Brahmaputra", "Narmada", 
 #             "Yamuna", "Mahanadi", "Kaveri”, “Tapti"]
#Hint: To get the ascii value of a charcter we need to use ord() function
#Ex: ord("A") returns an integer value i.e 65- ascci value of A

holy_rivers =["Ganges", "Godavari", "Brahmaputra", "Narmada", 
             "Yamuna", "Mahanadi", "Kaveri”]
#a=holy_rivers
for i in range(0,len(holy_rivers)):
    d=0
    for ch in holy_rivers[i]:
        d=d+ord(ch)
        holy_rivers[i]==d
    print(holy_rivers[i])
