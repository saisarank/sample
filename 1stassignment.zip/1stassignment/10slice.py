"""
Write a program take input strings of equal length and the length of strings should be greater than 5 and display the output by combining last three characters from the 1st string with first three characters from the second string. 
Example: Input_Str1 = “PYTHON”
                  Input_Str2 = “PROGRAMMING”
                  Output = HONPRO
"""
z=""
Input_Str1 = "PYTHON"
Input_Str2 = "PROGRAMMING"
x=Input_Str1[3:]
y=Input_Str2[:3]
z=x+y
print(z)

