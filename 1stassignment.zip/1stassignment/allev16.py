#Write a program find all even numbers from the given list.

#Input_List = [18.8, “Hyd”, 18, 26.9, 19, “BANG”, 26, 33.7, 25, “CHEN”]
#Output = [18, 26]

x=[18.8, "Hyd", 18, 26.9, 19, "BANG", 26, 33.7, 25, "CHEN"]
for i in x:
    if type(i)==int:
       if i%2==0:
        print(i)
