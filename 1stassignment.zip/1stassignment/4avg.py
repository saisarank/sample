"""
Given dictionary representing a student name as a key and corresponding value is a grade which he obtained in different subjects.  WAP update each dict value with average score obtained by each student respectively. 
scores = {“Student1”: [65, 68, 59, 52, 69, 65, 55, 59], 
                 “Student2”: [60, 64, 60, 60, 88, 64, 68, 75],
                 “Student3”: [59, 72, 64, 62, 66, 68, 72, 73], 
                “Student4”: [82, 62, 61, 54, 71, 89, 75, 73]
                }
"""
scores = {"Student1": [65, 68, 59, 52, 69, 65, 55, 59], 
                 "Student2": [60, 64, 60, 60, 88, 64, 68, 75],
                 "Student3": [59, 72, 64, 62, 66, 68, 72, 73], 
                "Student4": [82, 62, 61, 54, 71, 89, 75, 73]
                }

for k,v in scores.items():
    print({k:((v[0]+v[1]+v[2]+v[3]+v[4]+v[5]+v[6]+v[7])/8)})
