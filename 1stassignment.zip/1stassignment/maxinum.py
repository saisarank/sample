def get_max(x):
    max_ele=x[0]
    for ele in x:
        if ele>max_ele:
            max_el=ele
    return max_ele
z=[82,62,61,54,71,89,75,73]
print(get_max(z))
