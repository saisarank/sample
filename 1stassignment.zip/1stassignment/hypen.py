#Write a program join each and every character from the given string with hyphen(-)
#Example: 
#Input_str = “PYTHON”
#Output = P-Y-T-H-O-N
#Note: Please Don’t use join () function.


def removeSpaces(string): 
	string = string.replace('','-') 
	return string 
string = "Python"
print(removeSpaces(string)) 


