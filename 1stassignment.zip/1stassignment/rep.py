"""
WAP replace each string from the given list with the same string which is repeated with length of the string. 
Example: 
Input = [“A”, “AB”, “ABC”, “ABCD”]
Output = [“A”, “ABAB”,          “ABCABCABC”,“ABCDABCDABCDABCD”] 
"""

i= ["A", "AB", "ABC", "ABCD"]
z=[i[0]*1,i[1]*2,i[2]*3,i[3]*4]
print(z)
