#6.WAP print all duplicated values in descending order from the given input list. 
#Input_list = [401, 403, 409, 403, 453, 402, 438, 401, 444]


a=[401, 403, 409, 403, 453, 402, 438, 401, 444]
d=[]
z=[]
for i in a:
    if i not in d:
        d.append(i)
    else:
        z.append(i)
        print(z)

