"""
str="sarank"
#if(len(str)==0):
z=str[3:]
x=str[:3]
s=z+x
print(s)
"""


str ="saranksainadhp"
a=len(str)>>1
x=str[:a]
print(x)
z=str[a:]
s=z+x
print(s)
