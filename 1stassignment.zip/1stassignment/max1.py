#WAP find the average of given list of elements representing a grade of student.
grades = [84, 84, 93, 78, 86, 73],

a=[84,84,93,78,86,73]
z=max(a)
a[0]=z
a[1]=z
a[2]=z
a[3]=z
a[4]=z
a[5]=z

print (a)
