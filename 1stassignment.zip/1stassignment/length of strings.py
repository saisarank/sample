#Write a program take 10 input strings of different lengths from the user and
#store all the strings into a list and display only odd length strings are the
#output in a list format.


str=["sai","ramu","vamsi","saran","nadh","yugesh","mani","naveen","krishna","mahesh"]
for i in str:
    print(len(i))
    if len(i)%2!=0:
        print("odd list:")
    else:
        print("no:")
       
"""
def change_char(str1):
  char = str1[0]
  str1 = str1.replace(char, '$')
  str1 = char + str1[1:]
  

  return str1

print(change_char('restart'))
"""
