#2.WAP combine all the first characters from given list representing a some of the compelling qualities of a great leader.   
#qualities = [“Passion”, “Yearning”, “Transparency”, “Humble”, “open-minded”, “Noble”]

a=["Passion","Yearing","Transparency","Humble","Open-minded","Noble"]
y=[]
for i in a:
    print(i[0])
    y.append(i[0])
print(y)
